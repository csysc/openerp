{
	"name" : "Csysc Extra Reports",
	"version" : "1.0",
	"author" : "Company System Controll LTD",
	"website" : "",
	"category" : "Generic Modules/Others",
	"depends" : ["base","account","sale","product","stock","mrp","csysc_inh_account_inv_tax","csysc_sales_order_row_tax"],
	"description" : "Overvrite account invoice line.>> Put and calculate tax by line.", "other"
	"init_xml" : [],
	"demo_xml" : [],
	"update_xml" : ["reports.xml",],
	"active": False,
	"installable": True
}
